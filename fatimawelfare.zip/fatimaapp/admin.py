from django.contrib import admin
from .models.collectmony import Collectform
from .models.bloodgroup import Bloodpersons
from .models.addbloodperson import Addbloodperson
from .models.monthly_person_done import Monthly_done


# Register your models here.

class AdminTotalcollection(admin.ModelAdmin):
    list_display = ['name', 'cast', 'amount', 'cashholder']


class Adminbloodgroup(admin.ModelAdmin):
    list_display = ['bloodgroup']


class Adminbloodperson(admin.ModelAdmin):
    list_display = ['name', 'cast', 'bloodgroup', 'phone', 'lastdate']


class AdminMonthlyDone(admin.ModelAdmin):
    list_display = ['month_date', 'month_status']


admin.site.register(Collectform, AdminTotalcollection)
admin.site.register(Bloodpersons, Adminbloodgroup)
admin.site.register(Addbloodperson, Adminbloodperson)
admin.site.register(Monthly_done, AdminMonthlyDone)
