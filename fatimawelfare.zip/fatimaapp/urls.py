from django.urls import path
from fatimaapp.views import collectfrom, totalcollection, delete_collection, bloodgroups, totalbloodpersons, \
    delete_persons, spent_form, spent_table, home, monthly_persons, delete_spent, monthly_persons_table, \
    monthly_person_done, signup, login, monthly_family_form,monthly_family_table, delete_monthly_p, monthly_family_done

urlpatterns = [
    path('', home.Home.as_view(), name='homepage'),
    path('collections/monycollectform.html', collectfrom.Collection.as_view(), name='monycollectform'),
    path('collections/totalcollection.html', totalcollection.Totalcollection.as_view(), name='totalcollection'),
    path('collections/delete_collection.html/<str:pk>', delete_collection.delete_collection, name='delete_collection'),
    path('collections/delete_persons.html/<str:pk>', delete_persons.delete_persons, name='delete_persons'),
    path('collections/delete_spent.html/<str:pk>', delete_spent.delete_s, name='delete_spent'),
    path('collections/delete_monthly_p.html/<str:pk>', delete_monthly_p.delete_monthly_p, name='delete_spent'),
    path('collections/addbloodform.html', bloodgroups.Fromtemplete.as_view(), name='blood'),
    path('collections/totalbloodpersons.html', totalbloodpersons.Total_blood_person.as_view(), name='blood'),
    path('collections/spent_form.html', spent_form.Spent_Form.as_view(), name='spent_form'),
    path('collections/spent_table.html', spent_table.Spent_table.as_view(), name='spent_table'),
    path('collections/monthlypersonsform.html', monthly_persons.Monthly_person_form.as_view(), name='monthly_persons'),
    path('collections/monthlypersonstable.html', monthly_persons_table.Monthly_persons_table.as_view(),
         name='monthly_persons_table'),

    path('collections/monthly_person_done.html', monthly_person_done.Monthly_per_done.as_view(),
         name='monthly_per_done'),
    path('collections/monthly_family_done.html', monthly_family_done.Monthly_family_done.as_view(),
         name='monthly_family_done'),
    path('collections/put_monthly_done.html/<str:pk>', monthly_person_done.monthly_status,
         name='put_monthly_done'),
    path('collections/put_family_done.html/<str:pk>', monthly_family_done.monthly_famiily_status,
         name='put_family_done'),
    path('collections/signup.html', signup.Signup.as_view(), name='signup'),
    path('collections/login.html', login.Login.as_view(), name='login'),
    path('collections/logout.html', login.logout, name='logout'),
    path('collections/monthly_family_form.html', monthly_family_form.Monthly_family_form.as_view(), name='monthly_f'),
    path('collections/monthly_family_table.html', monthly_family_table.Monthly_family_table.as_view(), name='monthly_f')

    # path('order/order.html', home.order, name='order')
]
