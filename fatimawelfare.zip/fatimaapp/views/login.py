from django.shortcuts import render, redirect
from django.contrib.auth.hashers import check_password
from ..models.using_people import Using_p
from django.views import View


class Login(View):
    def get(self, request):
        return render(request, 'collections/login.html')

    def post(self, request):
        email = request.POST.get('email')
        password = request.POST.get('password')
        customer = Using_p.get_customer_by_email(email)
        error_message = None
        print(error_message)
        if customer:
            flag = check_password(password, customer.password)
            if flag:
                request.session['admin_person'] = customer.id
                a = request.session['admin_person']
                return redirect('homepage')
            else:
                error_message = 'Password invalid'
        else:
            error_message = 'Invalid Email'

        return render(request, 'collections/login.html', {'error': error_message, 'email': email})

def logout(request):
    request.session.clear()
    return redirect('homepage')
