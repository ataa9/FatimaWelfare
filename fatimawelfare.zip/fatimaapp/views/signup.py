from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password
from ..models.using_people import Using_p
from django.views import View


class Signup(View):
    def get(self, request):
        return render(request, 'collections/signup.html')

    def post(self, request):
        postData = request.POST
        name = postData.get('name')
        email = postData.get('email')
        password = postData.get('password')
        value = {
            'name': name,
            'email': email
        }
        # velidation
        errorshown = None
        customer = Using_p(name=name,
                            email=email,
                            password=password)
        if (not name):
            errorshown = "Please Enter you name"
        elif len(name) < 4:
            errorshown = "Name At least type 4 letters"
        elif (not password):
            errorshown = "Please Enter you password"
        elif len(password) < 6:
            errorshown = "password At least type 4 letters"
        elif customer.isExist():
            errorshown = "already here"
        # saving

        if (not errorshown):
            customer.password = make_password(customer.password)
            customer.register()
            print('User Created')
            return redirect('login')
        else:
            data = {
                'err': errorshown,
                'value': value
            }
            return render(request, 'collections/signup.html', data)
