from django.shortcuts import render, redirect
from django.views import View
from ..models.monthly_family import Monthly_f


class Monthly_family_table(View):
    def get(self, request):
        monthly_family = Monthly_f.get_monthly_family()
        if 'admin_person' in request.session:
            return render(request, 'collections/monthly_family_table.html', {'monthly_family': monthly_family})
        else:
            return redirect('login')
