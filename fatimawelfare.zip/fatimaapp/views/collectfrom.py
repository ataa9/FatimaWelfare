from django.shortcuts import render, redirect
from fatimaapp.models.collectmony import Collectform
from django.views import View


class Collection(View):
    def get(self, request):
        if 'admin_person' in request.session:
            return render(request, 'collections/monycollectform.html')
        else:
            return redirect('login')

    def post(self, request):
        postData = request.POST
        name = postData.get('name')
        cast = postData.get('cast')
        amount = postData.get('amount')
        cashholder = postData.get('cashholder')

        entry = Collectform(name=name, cast=cast, amount=amount, cashholder=cashholder)
        entry.register()
        return render(request, 'collections/monycollectform.html')
