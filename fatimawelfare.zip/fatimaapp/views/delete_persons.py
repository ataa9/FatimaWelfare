from django.shortcuts import render, redirect
from ..models.addbloodperson import Addbloodperson


def delete_persons(request, pk):
    if 'admin_person' in request.session:
        delete_item = Addbloodperson.objects.get(id=pk)
        if request.method == 'POST':
            delete_item.delete()
            return redirect('/collections/totalbloodpersons.html')
        return render(request, 'collections/delete_persons.html', {'delete_item': delete_item})
    else:
        return redirect('login')
