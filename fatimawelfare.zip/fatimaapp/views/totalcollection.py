import datetime

from django.shortcuts import render, redirect
from ..models.collectmony import Collectform
from django.views import View
from django.core.paginator import Paginator, EmptyPage
from datetime import date
from django.utils import timezone


class Totalcollection(View):
    def get(self, request):
        if 'admin_person' in request.session:
            totalcollection = Collectform.collectmony()
            now = timezone.now()
            one_month_ago = datetime.datetime(now.year, now.month - 1, 1)
            page_n = request.GET.get('page', 1)
            p = Paginator(totalcollection, 20)
            try:
                page = p.page(page_n)
            except EmptyPage:
                page = p.page(1)

            sum = 0
            for item in totalcollection:
                sum += item.amount
            return render(request, 'collections/totalcollection.html',
                        {'page': page, 'sum': sum})
        else:
            return redirect('login')
