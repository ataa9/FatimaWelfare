from django.shortcuts import render
from ..models.spent_amount import Spent
from ..models.collectmony import Collectform
from ..models.monthly_person_done import Monthly_done
from ..models.using_people import Using_p
from django.views import View


class Home(View):
    def get(self, request):
        collection = Collectform.collectmony()
        spent = Spent.spenting()
        done_status = Monthly_done.get_monthly_done()
        using_p = Using_p.get_all_user()
        sum_coll = 0
        sum_spent = 0
        sum_done = 0

        for done in done_status:
            sum_done += done.month_status
        for coll in collection:
            sum_coll += coll.amount
        for spent_all in spent:
            sum_spent += spent_all.spent_amount
        sum_all = 0
        sum_all = sum_done + sum_coll
        remain = 0
        remain = sum_all - sum_spent

        return render(request, 'home.html',
                      {'sum_all': sum_all, 'sum_spent': sum_spent, 'remain': remain, 'using_p': using_p})
