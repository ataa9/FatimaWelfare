from django.shortcuts import render, redirect
from ..models.addbloodperson import Addbloodperson
from ..models.bloodgroup import Bloodpersons
from django.views import View


class Fromtemplete(View):
    def get(self, request):
        bloods = Bloodpersons.objects.all()
        if 'admin_person' in request.session:
            return render(request, 'collections/addbloodform.html', {'bloods': bloods})
        else:
            return redirect('login')

    def post(self, request):
        postData = request.POST
        name = postData.get('name')
        cast = postData.get('cast')
        bloodgroup_id = postData.get('bloodgroup')
        phone = postData.get('phone')
        lastdate = postData.get('date')

        entry = Addbloodperson(name=name, cast=cast, bloodgroup_id=bloodgroup_id, phone=phone,
                               lastdate=lastdate)
        entry.register()
        return redirect('/collections/addbloodform.html')
