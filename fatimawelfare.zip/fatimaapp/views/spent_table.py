from django.shortcuts import render, redirect
from ..models.spent_amount import Spent
from django.views import View
from django.core.paginator import Paginator, EmptyPage


class Spent_table(View):
    def get(self, request):
        if 'admin_person' in request.session:
            spent_data = Spent.spenting()
            sum = 0
            for total in spent_data:
                sum += total.spent_amount

            return render(request, 'collections/spent_table.html', {'spent_data': spent_data, 'sum': sum})
        else:
            return redirect('login')