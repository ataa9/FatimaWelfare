from django.shortcuts import render, redirect, HttpResponse
from ..models.spent_amount import Spent


def delete_s(request, pk):
    if 'admin_person' in request.session:
        delete_data = Spent.objects.get(id=pk)
        if request.method == 'POST':
            delete_data.delete()
            return redirect('/collections/spent_table.html')
        return render(request, 'collections/delete_spent.html', {'delete_data': delete_data})
    else:
        return redirect('login')
