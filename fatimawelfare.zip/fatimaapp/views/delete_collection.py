from django.shortcuts import render, redirect
from ..models.collectmony import Collectform


def delete_collection(request, pk):
    if 'admin_person' in request.session:
        delete_item = Collectform.objects.get(id=pk)
        if request.method == 'POST':
            delete_item.delete()
            return redirect('/collections/totalcollection.html')
        return render(request, 'collections/delete_collection.html', {'delete_item': delete_item})
    else:
        return redirect('login')


