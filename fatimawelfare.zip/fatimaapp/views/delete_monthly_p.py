from django.shortcuts import render, redirect
from ..models.monthly_persons import Monthly_person


def delete_monthly_p(request, pk):
    if 'admin_person' in request.session:
        delete_item = Monthly_person.objects.get(id=pk)
        if request.method == 'POST':
            delete_item.delete()
            return redirect('/collections/monthlypersonstable.html')
        return render(request, 'collections/delete_monthly_p.html', {'delete_item': delete_item})
    else:
        return redirect('login')
