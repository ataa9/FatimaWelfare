from django.shortcuts import render, redirect
from django.views import View
from ..models.monthly_persons import Monthly_person


class Monthly_persons_table(View):
    def get(self, request):
        monthly_person = Monthly_person.get_monthly_persons()
        if 'admin_person' in request.session:
            return render(request, 'collections/monthlypersonstable.html', {'monthly_person': monthly_person})
        else:
            return redirect('login')