from django.db import models


class Bloodpersons(models.Model):
    bloodgroup = models.CharField(max_length=30)

    @staticmethod
    def get_all_blood():
        return Bloodpersons.objects.all()

    def __str__(self):
        return self.bloodgroup
