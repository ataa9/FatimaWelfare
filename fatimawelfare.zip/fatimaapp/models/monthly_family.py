from django.db import models


class Monthly_f(models.Model):
    f_name = models.CharField(max_length=30)
    cast = models.CharField(max_length=30)
    phone = models.IntegerField(default=1)

    def register(self):
        self.save()

    @staticmethod
    def get_monthly_family():
        return Monthly_f.objects.all()
