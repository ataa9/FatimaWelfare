from django.db import models


class Collectform(models.Model):
    name = models.CharField(max_length=30)
    cast = models.CharField(max_length=30)
    amount = models.IntegerField(default=1)
    cashholder = models.CharField(max_length=30)
    datetime = models.DateTimeField(auto_now_add=True)

    def register(self):
        self.save()

    @staticmethod
    def collectmony():
        return Collectform.objects.all()
