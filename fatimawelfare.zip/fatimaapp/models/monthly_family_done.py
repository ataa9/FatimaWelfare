from django.db import models
from .monthly_family import Monthly_f


class Monthly_f_done(models.Model):
    month_date = models.DateField({'input_formats': ('%m')})
    monthly_f_number = models.IntegerField(default=0)
    monthly_f_done = models.CharField(max_length=30)

    def register(self):
        self.save()

    @staticmethod
    def monthly_per_id(month_per_id):
        monthly_id = Monthly_f.objects.filter(month_per=month_per_id)
        return monthly_id

    @staticmethod
    def get_monthly_done():
        return Monthly_f_done.objects.all()

    @staticmethod
    def get_monthly_data_by_id(month_per_id):
        month_date = Monthly_f_done.objects.filter(month_per_id)
        return month_date
