from django.db import models


class Monthly_person(models.Model):
    name = models.CharField(max_length=30)
    case = models.CharField(max_length=30)
    amount = models.IntegerField(default=1)
    phone = models.IntegerField(default=1)

    def register(self):
        self.save()

    @staticmethod
    def get_monthly_persons():
        return Monthly_person.objects.all()

    def __str__(self):
        return str(self.phone) or ''
