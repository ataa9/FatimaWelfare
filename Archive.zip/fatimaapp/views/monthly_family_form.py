from ..models.monthly_family import Monthly_f
from django.shortcuts import render, redirect
from django.views import View


class Monthly_family_form(View):
    def get(self, request):
        if 'admin_person' in request.session:
            return render(request, 'collections/monthly_family_form.html')
        else:
            return redirect('login')

    def post(self, request):
        postData = request.POST
        f_name = postData.get('f_name')
        cast = postData.get('cast')
        phone = postData.get('phone')

        enter = Monthly_f(f_name=f_name, cast=cast, phone=phone)
        enter.register()
        return render(request, 'collections/monthly_family_form.html')
