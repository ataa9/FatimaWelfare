from django.shortcuts import render, redirect
from django.views import View
from ..models.monthly_person_done import Monthly_done
from ..models.monthly_persons import Monthly_person
import array as arr
from datetime import datetime

today = datetime.now()


class Monthly_per_done(View):
    def get(self, request):
        if 'admin_person' in request.session:
            monthly_per = Monthly_person.objects.all()
            monthly_d = Monthly_done.objects.all()
            month1 = today.strftime("%B")
            monthly_done_s = []
            for e in monthly_per:
                for f in monthly_d:
                    thismonth = f.month_date.strftime("%B")
                    if (month1 == thismonth):
                        if (e.amount == f.month_status and e.id == f.monthly_boy):
                            monthly_done_s.append(f.monthly_boy)
            data={}
            data['monthly_per'] = monthly_per
            data['monthly_done_s'] = monthly_done_s
            return render(request, 'collections/monthly_person_done.html',
                          data)
        else:
            return redirect('login')


def monthly_status(request, pk):
    if 'admin_person' in request.session:
        monthly_per_id = Monthly_person.objects.get(id=pk)
        if request.method == 'POST':
            postData = request.POST
            month_status = postData.get('month_status')
            month_date = postData.get('month_date')
            monthly_boy = postData.get('monthly_boy')
            enter = Monthly_done(month_status=month_status, month_date=month_date, monthly_boy=monthly_boy)
            enter.register()
            return redirect('/collections/monthly_person_done.html')
        return render(request, 'collections/put_monthly_done.html', {'monthly_per_id': monthly_per_id})
    else:
        return redirect('login')

