from django.shortcuts import render, redirect
from ..models.addbloodperson import Addbloodperson
from ..models.bloodgroup import Bloodpersons
from django.views import View


class Total_blood_person(View):
    def get(self, request):
        if 'admin_person' in request.session:
            allbloods = Bloodpersons.get_all_blood()
            bloodgroup_id = request.GET.get('bloodgroup')
            if (bloodgroup_id):
                bloodperson = Addbloodperson.get_blood_by_filter(bloodgroup_id)
            else:
                bloodperson = Addbloodperson.add_blood_person()

            data = {}
            data['bloodperson'] = bloodperson
            data['allbloods'] = allbloods

            return render(request, 'collections/totalbloodpersons.html', data)
        else:
            return redirect('login')
