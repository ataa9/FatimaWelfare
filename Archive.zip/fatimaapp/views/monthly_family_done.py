from django.shortcuts import render, redirect
from django.views import View
from ..models.monthly_family_done import Monthly_f_done
from ..models.monthly_family import Monthly_f
import array as arr
from datetime import datetime

today = datetime.now()


class Monthly_family_done(View):
    def get(self, request):
        if 'admin_person' in request.session:
            monthly_f = Monthly_f.objects.all()
            monthly_d = Monthly_f_done.objects.all()
            month1 = today.strftime("%B")
            monthly_done_s = []
            for e in monthly_f:
                for f in monthly_d:
                    thismonth = f.month_date.strftime("%B")
                    if (month1 == thismonth):
                        if (e.id == f.monthly_f_number):
                            monthly_done_s.append(f.monthly_f_number)
            data = {}
            data['monthly_f'] = monthly_f
            data['monthly_done_s'] = monthly_done_s
            return render(request, 'collections/monthly_family_done.html',
                          data)
        else:
            return redirect('login')


def monthly_famiily_status(request, pk):
    if 'admin_person' in request.session:
        monthly_f_id = Monthly_f.objects.get(id=pk)
        if request.method == 'POST':
            postData = request.POST
            monthly_f_number = postData.get('monthly_f_number')
            month_date = postData.get('month_date')
            monthly_f_done = postData.get('monthly_f_done')
            enter = Monthly_f_done(monthly_f_number=monthly_f_number, month_date=month_date, monthly_f_done=monthly_f_done)
            enter.register()
            return redirect('/collections/monthly_family_done.html')
        return render(request, 'collections/put_family_done.html', {'monthly_f_id': monthly_f_id})
    else:
        return redirect('login')
