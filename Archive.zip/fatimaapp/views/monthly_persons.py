from ..models.monthly_persons import Monthly_person
from django.shortcuts import render, redirect
from django.views import View


class Monthly_person_form(View):
    def get(self, request):
        if 'admin_person' in request.session:
            return render(request, 'collections/monthlypersonsform.html')
        else:
            return redirect('login')

    def post(self, request):
        postData = request.POST
        name = postData.get('name')
        case = postData.get('case')
        amount = postData.get('amount')
        phone = postData.get('phone')

        enter = Monthly_person(name=name, case=case, amount=amount, phone=phone)
        enter.register()
        return render(request, 'collections/monthlypersonsform.html')
