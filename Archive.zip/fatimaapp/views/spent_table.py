from django.shortcuts import render, redirect
from ..models.spent_amount import Spent
from django.views import View
from django.utils import timezone
import datetime

from django.core.paginator import Paginator, EmptyPage


class Spent_table(View):
    def get(self, request):
        if 'admin_person' in request.session:
            spent_data = Spent.spenting()
            now = timezone.now()
            last_month_col = 0
            one_month_ago = datetime.datetime(now.year, now.month - 1, 1)
            last_month = one_month_ago.strftime("%B")
            for last_m in spent_data:
                last_month_data = last_m.datetime.strftime("%B")
                if (last_month_data == last_month):
                    last_month_col += last_m.spent_amount
            sum = 0
            for total in spent_data:
                sum += total.spent_amount
            page_n = request.GET.get('page', 1)
            p = Paginator(spent_data, 20)
            try:
                page = p.page(page_n)
            except EmptyPage:
                page = p.page(1)

            return render(request, 'collections/spent_table.html',
                          {'page': page, 'sum': sum, 'last_month_col': last_month_col, 'last_month':last_month})
        else:
            return redirect('login')
