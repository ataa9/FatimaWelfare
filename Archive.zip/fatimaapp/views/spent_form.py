from ..models.spent_amount import Spent
from django.views import View
from django.shortcuts import render, redirect


class Spent_Form(View):
    def get(self, request):
        if 'admin_person' in request.session:
            return render(request, 'collections/spent_form.html')
        else:
            return redirect('login')

    def post(self, request):
        postData = request.POST
        purpose = postData.get('purpose')
        spent_amount = postData.get('spent_amount')
        person = postData.get('person')

        enter = Spent(purpose=purpose, spent_amount=spent_amount, person=person)
        enter.register()
        return render(request, 'collections/spent_form.html')
