from django.db import models
from .bloodgroup import Bloodpersons


class Addbloodperson(models.Model):
    name = models.CharField(max_length=30)
    cast = models.CharField(max_length=30)
    bloodgroup = models.ForeignKey(Bloodpersons, on_delete=models.CASCADE)
    phone = models.CharField(max_length=50)
    lastdate = models.DateField({'input_formats': ('%d/%m/%Y',)})

    def register(self):
        self.save()

    @staticmethod
    def get_products_id(bloodgroup_id):
        blood_id = Bloodpersons.objects.filter(bloodgroup=bloodgroup_id)
        return blood_id

    @staticmethod
    def add_blood_person():
        return Addbloodperson.objects.all()

    @staticmethod
    def get_blood_by_filter(bloodgroup_id):
        if(bloodgroup_id):
            return Addbloodperson.objects.filter(bloodgroup=bloodgroup_id)
        else:
            return Addbloodperson.add_blood_person()
