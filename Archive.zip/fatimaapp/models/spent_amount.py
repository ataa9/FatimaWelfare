from django.db import models


class Spent(models.Model):
    purpose = models.CharField(max_length=50)
    spent_amount = models.IntegerField(default=1)
    person = models.CharField(max_length=30)
    datetime = models.DateTimeField(auto_now_add=True)

    def register(self):
        self.save()

    @staticmethod
    def spenting():
        return Spent.objects.all()
