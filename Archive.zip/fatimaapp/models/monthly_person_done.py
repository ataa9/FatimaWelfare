from django.db import models
from .monthly_persons import Monthly_person


class Monthly_done(models.Model):
    month_date = models.DateField({'input_formats': ('%m')})
    month_status = models.IntegerField(default=1)
    monthly_boy = models.IntegerField(default=0)

    def register(self):
        self.save()

    @staticmethod
    def monthly_per_id(month_per_id):
        monthly_id = Monthly_person.objects.filter(month_per=month_per_id)
        return monthly_id

    @staticmethod
    def get_monthly_done():
        return Monthly_done.objects.all()

    @staticmethod
    def get_monthly_data_by_id(month_per_id):
        month_date = Monthly_done.objects.filter(month_per_id)
        return month_date

    def __str__(self):
        return str(self.month_status)
